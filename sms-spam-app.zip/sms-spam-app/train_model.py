import pandas as pd
import nltk
import joblib
import re

from nltk.corpus import stopwords
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# download stopwords (aman kalau sudah ada)
nltk.download('stopwords')

# =====================
# 1. LOAD DATASET
# =====================
df = pd.read_csv('dataset/sms_spam.csv', encoding='latin-1')

print("Kolom dataset:", df.columns)

# =====================
# 2. AUTO DETEKSI KOLOM
# =====================
label_col = None
text_col = None

for col in df.columns:
    if df[col].dtype == object:
        if label_col is None:
            label_col = col
        elif text_col is None:
            text_col = col

if label_col is None or text_col is None:
    raise ValueError("Dataset harus punya minimal 2 kolom (label & text)")

df = df[[label_col, text_col]]
df.columns = ["label", "text"]

print("Menggunakan kolom:")
print("Label :", label_col)
print("Text  :", text_col)

# =====================
# 3. PREPROCESS TEXT
# =====================
stop_words = set(stopwords.words('english'))

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-z\s]', '', text)
    text = " ".join(word for word in text.split() if word not in stop_words)
    return text

df['text'] = df['text'].apply(clean_text)

# ubah label ke angka
df['label'] = df['label'].astype(str).str.lower()
df['label'] = df['label'].map({
    'spam': 1,
    'ham': 0
})

df = df.dropna()

# =====================
# 4. SPLIT DATA
# =====================
X_train, X_test, y_train, y_test = train_test_split(
    df['text'],
    df['label'],
    test_size=0.2,
    random_state=42
)

# =====================
# 5. TF-IDF
# =====================
vectorizer = TfidfVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# =====================
# 6. TRAIN MODEL
# =====================
model = LogisticRegression(max_iter=1000)
model.fit(X_train_vec, y_train)

# =====================
# 7. EVALUASI
# =====================
y_pred = model.predict(X_test_vec)
accuracy = accuracy_score(y_test, y_pred)

print("\n====================")
print("Model berhasil dilatih 🎉")
print("Akurasi:", accuracy)
print("====================\n")

# =====================
# 8. SIMPAN MODEL
# =====================
joblib.dump(model, "spam_model.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")

print("Model disimpan sebagai spam_model.pkl")
print("Vectorizer disimpan sebagai vectorizer.pkl")
