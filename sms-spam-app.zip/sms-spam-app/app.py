import streamlit as st
import joblib

# Load model & vectorizer
model = joblib.load("spam_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

# Judul aplikasi
st.set_page_config(page_title="Deteksi SMS Spam", page_icon="📩")
st.title("📩 Aplikasi Deteksi SMS Spam")
st.write("Masukkan isi SMS, lalu sistem akan memprediksi apakah **Spam** atau **Normal**.")

# Input teks
sms = st.text_area("✉️ Isi SMS", height=150)

# Tombol prediksi
if st.button("🔍 Prediksi"):
    if sms.strip() == "":
        st.warning("⚠️ Teks SMS tidak boleh kosong")
    else:
        sms_vec = vectorizer.transform([sms])
        prediction = model.predict(sms_vec)[0]

        if prediction == "spam":
            st.error("🚨 Hasil: **SPAM**")
        else:
            st.success("✅ Hasil: **NORMAL / BUKAN SPAM**")
