# SMS Spam Classification using Machine Learning

Proyek ini merupakan implementasi klasifikasi SMS Spam dan Ham
menggunakan algoritma Machine Learning Naive Bayes dan Logistic Regression
serta diimplementasikan dalam aplikasi berbasis Streamlit.

## Dataset
Dataset yang digunakan adalah sms_spam.csv yang berisi pesan SMS
dengan dua label:
- spam
- ham

## Algoritma
- Naive Bayes
- Logistic Regression

## Tools
- Python
- Scikit-learn
- Streamlit

## Cara Menjalankan Aplikasi
1. Install dependency
pip install -r requirements.txt

2. Jalankan aplikasi
streamlit run sms_spam.app

## Hasil
Model Naive Bayes memberikan akurasi yang lebih tinggi dibandingkan
Logistic Regression dalam klasifikasi SMS Spam.

## Author
Faqih Rafiq Aufa
